<?php
	$dbHost = "localhost";
	$dbDatabase = "u747325399_church";
	$dbPasswrod = "Church@1";
	$dbUser = "u747325399_church";
	$mysqli = new mysqli($dbHost, $dbUser, $dbPasswrod, $dbDatabase);
    $conn = new mysqli($dbHost, $dbUser, $dbPasswrod, $dbDatabase);
?>