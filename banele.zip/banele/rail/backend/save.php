<?php
session_start();
include '../database/conn.php';
if(count($_POST)>0){
	if($_POST['type']==1){
	    
			$housecode=$_POST['housecode'];
			$tenant=$_POST['tenant'];
			$station=$_POST['station'];
			$emater=$_POST['emeter'];
			$wmeter=$_POST['wmeter'];
			
			
			
			
			
		if($housecode !=""){
			$sql = "INSERT INTO `house`(`housecode`, `tcode`, `station`,`electricity_meter`,`water_meter`) 
			VALUES ('$housecode','$tenant','$station','$emater', '$wmeter')";
			if (mysqli_query($conn, $sql)) {
				echo json_encode(array("statusCode"=>200));

				


			} 
			else {
				//echo "Error: " . $sql . "<br>" . mysqli_error($conn);
					echo json_encode(array("statusCode"=>206));
			}
			mysqli_close($conn);
		}
		else{
				echo json_encode(array("statusCode"=>206));
		}
	}
}



if(count($_POST)>0){
	if($_POST['type']==6){
	    
			$minprevwater=$_POST['minprevwater'];
			$minprevelec=$_POST['minprevelec'];
			$twater=$_POST['twater'];
			$telec=$_POST['telec'];
			$tnt=$_POST['tnt'];
			$month = $_POST['mnts'];
			$years = date("Y");
			$billdate = date("d/m/Y");
			$id = $tnt.$month.$years;

			$currentelec=$_POST['currentelec'];
			$currectwat=$_POST['currectwat'];
			$comments=$_POST['comments'];

			$previouswater=$_POST['ffprevwater'];
			$previouselectricity=$_POST['ffprevelec'];

			
				
			
				$digits = 4; 
				$randomise =  str_pad(rand(0, pow(10, $digits)-1), $digits, '0', STR_PAD_LEFT); 




   $tquery = "SELECT MAX(invoicenumber) AS LargestPrice FROM invoices; ";
   $tresult8 = mysqli_query($conn, $tquery);

   // get the query result without the while loop
   $rowq = mysqli_fetch_array($tresult8);
  $hh = $rowq['LargestPrice'];
   $topidcount = $hh +1;

				
				
$ste = "SELECT station, region, tcode FROM house WHERE housecode='$tnt' ";
$res = $conn->query($ste);

if ($res->num_rows > 0) {
  // output data of each row
  while($rowd = $res->fetch_assoc()) {
      
      $stationz = $rowd['station'];
       $regionz = $rowd['region'];
       $tent = $rowd['tcode'];
    
		
																																							
			
			if($minprevwater !="" && $minprevelec !="" &&  $telec !="" && $billdate!=""){
			$sql = "INSERT INTO `invoices`(`id`,`tenant`, `w_units`, `e_units`,`electricity_charge`, `water_charge`, `month`, `year`, `billdate`,  `house_code`,`currentelec`, `currentwat`, `prevwater`, `prevelec`, `comments`, `invoicenumber`, `station`) 
			VALUES ('$id','$tent','$minprevwater','$minprevelec','$telec', '$twater', '$month','$years' , '$billdate', '$tnt', '$currentelec', '$currectwat', '$previouswater', '$previouselectricity', '$comments', '$topidcount', '$stationz')";
			if (mysqli_query($conn, $sql)) {
				//echo json_encode(array("statusCode"=>200));
		
				$response = array(
					'statusCode'=>200,
					'month'=>$month,
					'tnt'=>$tnt
					);
				echo json_encode($response);
			}else {
				//echo "Error: " . $sql . "<br>" . mysqli_error($conn);
				$response = array(
					'statusCode'=>201,
					'month'=>$month,
					'tnt'=>$tnt
					);
				echo json_encode($response);
			}
			//mysqli_close($conn);
		}
		
  }
} else {
  echo "0 results";
}

			//	}
	
			
	
}}


if(count($_POST)>0){
	if($_POST['type']==2){
		$housecode=$_POST['uhousecode'];
		$tenant=$_POST['utenant'];
		$autoid=$_POST['uautoid'];
		$station=$_POST['ustation'];
		$emeter=$_POST['uemeter'];
		$wmeter=$_POST['uwmeter'];
		
		$sql = "UPDATE `house` SET `tcode`='$tenant',`station`='$station',`electricity_meter`='$emeter', `water_meter`='$wmeter', `housecode`='$housecode'  WHERE  `autoid`=$autoid";
		if (mysqli_query($conn, $sql)) {
			echo json_encode(array("statusCode"=>200));
		} 
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}
if(count($_POST)>0){
	if($_POST['type']==3){
		$id=$_POST['id'];
		$sql = "DELETE FROM house WHERE `housecode` = '$id'";
		if (mysqli_query($conn, $sql)) {
			echo $id;
		} 
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}
if(count($_POST)>0){
	if($_POST['type']==4){
		$id=$_POST['id'];
		$sql = "DELETE FROM user WHERE id in ($id)";
		if (mysqli_query($conn, $sql)) {
			echo $id;
		} 
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}

?>