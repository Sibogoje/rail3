<?php
session_start();
include "database/conn.php";
?>
<html>
<head>
<title>Billing</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet">
    <link href="file.css" rel="stylesheet">
    <script src="http://code.jquery.com/jquery-1.11.1.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.3.4/jspdf.debug.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-T8Gy5hrqNKT+hzMclPo118YTQO6cYprQmhrYwIiQ/3axmI1hQomh7Ud2hPOy8SP1" crossorigin="anonymous">
<link href='https://fonts.googleapis.com/css?family=Roboto' rel='stylesheet'>



<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>


</head>
<body>
<?php
if($_SESSION["id"]) {
?>
<input type="checkbox" name="mobile-nav" id="mobile-nav" class="gaadiexp-check" onchange="this.blur()">
<label for="mobile-nav" class="gaadiexp white" tabindex="0"><span></span></label>
<nav role="navigation" class="header-nav" >
    <div class="fixed-nav" style="background-color: #000930;">
        <a class="navbar-brand" style="margin-left:50px;" href="auction.gaadiexpert.com"></a>
        <div style="display:flex; justify-content: left;   position: absolute;
  right: 0px;">
        <img class="img-responsive" src="images/logo1.png" style="display:flex; justify-content: left; margin-top:2px; width:180px;  ">
     
        </div>
        <div class="menu">
            <div class="list-group-hover sidebar-widget-1">
	            <ul class="list-unstyled">
            <li><a href="home.php" class="list-group-item"><i class="fa fa-tachometer"></i> Dashboard <span class="badge"></span> </a></li>
            <li><a href="reports.php" class="list-group-item"><i class="fa fa-file"></i> Reports</a> </li>
            <li><a href="constants.php" class="list-group-item"><i class="fa fa-gear"></i> Constants</a> </li>
            <li><a href="tenants.php" class="list-group-item"><i class="fa fa-list"></i>  All tenants</a> </li>
            <li><a href="houses.php" class="list-group-item"><i class="fa fa-home"></i> Houses Data</a> </li>
            <li><a href="billing.php" class="list-group-item bg-active"><i class="fa fa-file"></i> Billing</a> </li>
    

            <li><a href="script/logout.php" class="list-group-item"><i class="fa fa-power-off"></i> Log Out</a> </li>
            </ul>
         </div>
        </div>
    </div>
</nav>


<div class="container">
    <div class="row">
    <div class="container" style="margin-top: 80px;">


<div class="container">
    
    <div class="row grid-divider">
    <div class="col-sm-4">
      <div class="col-padding">
        <h3>Calculator</h3>
        <form id="user_form">
										
                    
						<div class="form-group">
							<label>House</label>
							
                            <select id="tenant" name="tenante" class="form-control js-example-basic-single" required>
                                <option value="">Select House</option>
                                <?php
				           $result2 = mysqli_query($conn,"SELECT * FROM `house` ");
					
					while($row = mysqli_fetch_array($result2)) {
                       $hh = $row['housecode'];
                       echo "<option value=".$row['housecode'].">".$row['station']." ".$row['housecode']." </option>";
                       

                    }
				       ?>
                             </select>
						</div>
					
						<div class="form-group">
							<label>Month To Be Billed</label>
							
                            <select id="month" name="month" class="form-control" required>
                                <option value=""></option>
                                <?php
				           $result2 = mysqli_query($conn,"SELECT * FROM months  ");
					
					while($row = mysqli_fetch_array($result2)) {
                       echo "<option value=".$row['month'].">".$row['month']."</option>";
                    }
				       ?>
                             </select>
						</div>
                        <div style="display: table" >			
                         <div class="form-group" style="width: 50%; display: table-cell">
							<label>Current Water Units</label>
							<input type="number" id="calprevwater" name="calprevwater" class="form-control" placeholder="Last Water Bill" required>
                           
						</div>	
                        <div class="form-group" style="width: 50%; display: table-cell">
							<label>Current Electriciy Units</label>
							<input type="number" id="calprevelec" name="calprevelec" class="form-control" placeholder="Last Electr.. Bill" required>
                           
						</div>
                </div>	
                        						
					</div>
					<div class="modal-footer">
					    <input type="hidden" value="1" name="type">
					
					</div>
				</form>
      
    </div>



    <div class="col-sm-4">
      <div class="col-padding">
        <h3>Results</h3>
        <form id="results">
				<div style="display: table" >			
                         <div class="form-group" style="width: 50%; display: table-cell">
							<label>Previous Water Bill</label>
							<input type="city" id="ffprevwater" name="ffprevwater" value="" class="form-control" placeholder="Last Water Bill" required readonly>
                           
						</div>	
                        <div class="form-group" style="width: 50%; display: table-cell">
                        <label>Previous Electriciy Bill</label>
                      
						<input type='city' id='ffprevelec' name='ffprevelec' value="" class='form-control' placeholder="Last Electricity Bill"  required  readonly>
                      
						</div>
                </div>


                <div style="display: table" >			
                         <div class="form-group" style="width: 50%; display: table-cell">
							<label>Water Units for this month</label>
							<input type="number" id="minprevwater" name="minprevwater" class="form-control" placeholder="Last Water Bill" required readonly>
                           
						</div>	
                        <div class="form-group" style="width: 50%; display: table-cell">
							<label>Electricity Units for this month</label>
							<input type="number" id="minprevelec" name="minprevelec" class="form-control" placeholder="Units For the Month" required readonly>
                           
						</div>
                </div>
                <div style="display: table" >			
                         <div class="form-group" style="width: 50%; display: table-cell">
							<label>Total Water Bill</label>
							<input type="city" id="twater" name="twater" class="form-control" placeholder="Bill for this month" required readonly>
                           
						</div>	
                        <div class="form-group" style="width: 50%; display: table-cell">
							<label>Total Electriciy Bill</label>
							<input type="number" id="telec" name="telec" class="form-control" placeholder="Bill For this Month" required readonly>
                           
						</div>
                </div>
						
					
						
                       	
                        <div class="form-group">
							<label>Comments</label>
							<input type="city" id="comments" name="comments" class="form-control" >
						</div>	
                        						
					</div>
					<div class="modal-footer">
                    <input  type="hidden" value="" name="currentelec" id="currentelec">
                    <input  type="hidden" value="" name="currectwat" id="currectwat">
                    <input  type="hidden" value="" name="previouswater" id="previouswater">
                    <input  type="hidden" value="" name="previouselectricity" id="previouselectricity">
					    <input type="hidden" value="6" name="type">
                        <input  type="hidden" value="" name="tnt" id="tnt">
                        <input  type="hidden" value="" name="mnts" id="mnts">
                         <div class="form-group">
                             <button type="submit"  class="btn btn-success"  id="addinv" name="addinv" value="Save" style="width: 100%">Save</button>
						</div>
						
						
					</div>

                   
				</form>
      </div>
    

    <div class="col-sm-4">
      <div class="col-padding">
        <h3>Print Invoices</h3>
<?php $actio = "pri/index.php"; ?>
<form method="POST" action="pri/index.php" id="chuza">
                <select id="tenanted" name="tenanted" class="form-control js-example-basic-single" required>
                                <option value="">Select Invoice to Print</option>
                                <?php
				           $result2 = mysqli_query($conn,"SELECT * FROM  `invoices` ");
					
					while($row = mysqli_fetch_array($result2)) {
                    $fg = $row['month'];
                       echo "<option value=".$row['house_code'].">".$row['house_code']." ".$row['month']." -  ".$row['year']."</option>";
                                       
                    }?>
                             </select>
                            
                             <br>
                              <br> <br>

                             <select id="mnm" name="mnm" class="form-control" required>
                                <option value="">Select Invoice to Print</option>
                                <?php
				           $result2 = mysqli_query($conn,"SELECT * FROM  `months` ");
					
					while($row = mysqli_fetch_array($result2)) {
                    $fg = $row['month'];
                       echo "<option value=".$row['month'].">".$row['month']."</option>";
                                       
                    }?>
                             </select>
                             <br> <br>
                             <div style="width: 100%;">
                              <div id="nd1" style="margin-left: 0; padding: 5px;">
                              <input type="radio" id="typed1" name="typing" value="All" checked> 
                              <label for="typed1">All  </label>
                              </div>
                              
                              <div id="nd2" style="padding: 5px;">
                              <input type="radio" id="typed2" name="typing" value="water">
                              <label for="typed2">Water  </label>
                              </div>
                              
                              <div id="nd3" style="margin-right: 0; padding: 5px;">
                              <input type="radio" id="typed3" name="typing" value="Electricity">
                              <label for="typed3">Electricity  </label>
                              </div>
                             </div>
                             <br><br>
                        
                             <div class="form-group">
                             <input type="submit" formtarget="_blank" class="btn btn-success"  id="prints" name="prints" value="Preview Invoice">
						</div>
                        
				      
</form>








        
        </div>

</div>
</div>

</div>
    
</div>
 </div>
</div>
<script type="text/javascript">
$(document).ready(function() {
    $('.js-example-basic-single').select2();
});

</script>
<script type="text/javascript">


$(document).on('click','#addinv',function(e) {
		var data = $("#results").serialize();
		$.ajax({
			data: data,
			type: "post",
			url: "backend/save.php",
			success: function(dataResult){
					var dataResult = JSON.parse(dataResult);
					if(dataResult.statusCode==200){
                        location.reload();
					}else if(dataResult.statusCode==201){
                        var month = (dataResult.month);
                       var tnt = (dataResult.tnt);
					   alert("Data for "+tnt+" for Month: "+month+" already exists");
                       location.reload();	
					}
			}
		});
	});
   

$('#tenant').change(function() {
       
 var jk = $('#tenant option:selected').val();

 $('#tnt').val(jk);
  
	
});   

$('#month').change(function() {
    var jk2 = $('#month option:selected').val();

$('#mnts').val(jk2);

  var data = $("#user_form").serialize();
		$.ajax({
			data: data,
			type: "post",
			url: "backend/billing.php",
			success: function(dataResult){
					var dataResult = JSON.parse(dataResult);
					if(dataResult.statusCode==200){
                       $("#ffprevelec").val(dataResult.prev_elec);
                       $("#ffprevwater").val(dataResult.prev_water);
	

                        			
                     //   location.reload();						
					}
					else if(dataResult.statusCode==201){
                       $("#ffprevelec").val(0);
                       $("#ffprevwater").val(0);
					}
			}
		});
});

$('#calprevwater').on("input", function() {
    $('#currectwat').val($(this).val());
    $('#unitsd').val($(this).val());
var inp = $(this).val() - $('#ffprevwater').val();
$('#minprevwater').val(inp);
if (inp < 11){
    $('#twater').val(82.62 + 71.21);
}else if (inp > 10 && inp < 16){
    $('#twater').val(82.62 + 89.76);
}else if (inp > 15 && inp < 51  ){
    $('#twater').val(82.62 + 117.69);
}else {
    $('#twater').val(82.62 + 149.56);
}
	
});

$('#calprevelec').on("input", function() {
    $('#currentelec').val($(this).val());
var inp2 = $(this).val() - $('#ffprevelec').val();
$('#minprevelec').val(inp2);
if (inp2 < 100) {
    $('#telec').val(180);
} else if (inp2 > 100){
var yh = inp2 * 1.8;
    $('#telec').val(180 + yh);  

}

	
});


function generatePDF() {
 var doc = new jsPDF();  //create jsPDF object
  doc.fromHTML(document.getElementById("results"), // page element which you want to print as PDF
  15,
  15, 
  {
    'width': 170  //set width
  },
  function(a) 
   {
    doc.save("HTML2PDF.pdf"); // save file name as HTML2PDF.pdf
  });
}
</script>
<script>
$(document).ready(function () {
    $('#typed1').click(function () {
        if ($(this).is(':checked')) {
            $("#chuza").attr('action', 'pri/index.php');
        }
    });

    $('#typed2').click(function () {
        if ($(this).is(':checked')) {
             $("#chuza").attr('action', 'pri/index3.php');
        }
    });
    
     $('#typed3').click(function () {
        if ($(this).is(':checked')) {
           // alert("Transfer Thai Gayo");
            $("#chuza").attr('action', 'pri/index4.php');

        }
    });
});
</script>
<?php
}else{
    header('Location: index.php');

} 
?>
</body>
</html>